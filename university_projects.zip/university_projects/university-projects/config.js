module.exports = {
    db: {
      host: 'localhost',
      user: 'root',
      password: '123456789',
      database: 'university_projects'
    }
  };