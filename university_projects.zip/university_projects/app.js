require('dotenv').config(); // Carregar variáveis de ambiente
const express = require('express');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456789',
  database: 'university_projects',
});

// Inicializar banco de dados
const initializeDatabase = async () => {
  try {
    await db.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nome VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        matricula VARCHAR(255) NOT NULL UNIQUE,
        curso VARCHAR(255) NOT NULL,
        senha VARCHAR(255) NOT NULL
      );
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nome_do_projeto VARCHAR(255) NOT NULL,
        curso VARCHAR(255) NOT NULL,
        descricao TEXT NOT NULL
      );
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS comments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        project_id INT,
        text TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      );
    `);

    await db.execute(`
      CREATE TABLE IF NOT EXISTS favorites (
        id INT PRIMARY KEY AUTO_INCREMENT,
        project_id INT,
        user_id INT,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE KEY unique_favorite (project_id, user_id)
      );
    `);
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1); // Exit process if database initialization fails
  }
};

// Middleware de autenticação JWT
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Inicializar banco de dados e iniciar servidor
initializeDatabase().then(() => {
  app.listen(3000, () => {
    console.log('Server listening on port 3000');
  });
});

// Rotas da API

// Registro de usuário
app.post(
  '/register',
  [
    body('nome').notEmpty().withMessage('Nome é obrigatório'),
    body('email').isEmail().withMessage('Email inválido'),
    body('matricula').notEmpty().withMessage('Matrícula é obrigatória'),
    body('curso').notEmpty().withMessage('Curso é obrigatório'),
    body('senha').isLength({ min: 6 }).withMessage('Senha deve ter pelo menos 6 caracteres'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { nome, email, matricula, curso, senha } = req.body;

    try {
      const hashedPassword = await bcrypt.hash(senha, 10);

      await db.execute(
        `
        INSERT INTO users (nome, email, matricula, curso, senha)
        VALUES (?, ?, ?, ?, ?)
      `,
        [nome, email, matricula, curso, hashedPassword]
      );

      res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({ message: 'Error creating user' });
    }
  }
);

// Login de usuário
app.post(
  '/login',
  [
    body('email').isEmail().withMessage('Email inválido'),
    body('senha').notEmpty().withMessage('Senha é obrigatória'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, senha } = req.body;

    try {
      const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);

      if (rows.length === 0) return res.status(400).json({ message: 'User not found' });

      const user = rows[0];

      const isMatch = await bcrypt.compare(senha, user.senha);

      if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

      const payload = { id: user.id, email: user.email };
      const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '5h' });

      res.json({ token, userId: user.id });
    } catch (err) {
      console.error('Server error:', err);
      res.status(500).json({ message: 'Server error' });
    }
  }
);

// Criação de projeto
app.post(
  '/create-project',
  authenticateJWT,
  [
    body('nome_do_projeto').notEmpty().withMessage('Nome do projeto é obrigatório'),
    body('curso').notEmpty().withMessage('Curso é obrigatório'),
    body('descricao').notEmpty().withMessage('Descrição é obrigatória'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { nome_do_projeto, curso, descricao } = req.body;

    try {
      await db.execute(
        `
        INSERT INTO projects (nome_do_projeto, descricao, curso)
        VALUES (?, ?, ?)
      `,
        [nome_do_projeto, descricao, curso]
      );

      res.status(201).json({ message: 'Project created successfully' });
    } catch (error) {
      console.error('Error creating project:', error);
      res.status(500).json({ message: 'Error creating project' });
    }
  }
);

// Busca de projetos
app.get('/search-projects', authenticateJWT, async (req, res) => {
  const query = req.query.query || '';
  const userId = req.user.id;

  try {
    const [projects] = await db.execute(
      'SELECT * FROM projects WHERE nome_do_projeto LIKE ? OR descricao LIKE ?',
      [`%${query}%`, `%${query}%`]
    );

    for (let project of projects) {
      const [comments] = await db.execute(
        'SELECT * FROM comments WHERE project_id = ?',
        [project.id]
      );
      project.comments = comments;

      const [favoriteRows] = await db.execute(
        `
        SELECT COUNT(*) AS isFavorited
        FROM favorites
        WHERE project_id = ? AND user_id = ?
      `,
        [project.id, userId]
      );

      project.isFavorited = favoriteRows[0].isFavorited > 0;
    }

    if (projects.length > 0) {
      res.status(200).json(projects);
    } else {
      res.status(404).json({ message: 'No projects found' });
    }
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Favoritar projeto
app.post('/projects/:projectId/favorite', authenticateJWT, async (req, res) => {
  const { projectId } = req.params;
  const userId = req.user.id;

  try {
    await db.execute(
      `
      INSERT INTO favorites (project_id, user_id)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)
    `,
      [projectId, userId]
    );

    res.json({ message: 'Favorite status updated' });
  } catch (error) {
    console.error('Error updating favorite status:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Remover favorito de projeto
app.delete('/projects/:projectId/favorite', authenticateJWT, async (req, res) => {
  const { projectId } = req.params;
  const userId = req.user.id;

  try {
    await db.execute(
      `
      DELETE FROM favorites
      WHERE project_id = ? AND user_id = ?
    `,
      [projectId, userId]
    );

    res.json({ message: 'Favorite status removed' });
  } catch (error) {
    console.error('Error removing favorite status:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

//Adicionar Comentário
app.post('/comments/:projectid', async (req, res) => {
  const { projectid } = req.params;
  const { text } = req.body;

  if (!text) {
    return res.status(400).json({ error: 'Comment text is required' });
  }

  try {
    const [result] = await db.execute(
      'INSERT INTO comments (project_id, text) VALUES (?, ?)',
      [projectid, text]
    );
    res.json({ message: 'Comment added successfully', comment: result.insertId });
  } catch (err) {
    console.error('Error adding comment:', err);
    res.status(500).json({ error: 'Failed to add comment' });
  }
});
// Atualizar comentário
app.put('/projects/:projectId/comments/commentId',
  authenticateJWT,
  [body('text').notEmpty().withMessage('Texto do comentário é obrigatório')],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { projectId, commentId } = req.params;
    const { text } = req.body;

    try {
      await db.execute(
        'UPDATE comments SET text = ? WHERE id = ? AND project_id = ?',
        [text, commentId, projectId]
      );
      res.json({ message: 'Comment updated successfully' });
    } catch (err) {
      console.error('Error updating comment:', err);
      res.status(500).json({ message: 'Failed to update comment' });
    }
  }
);

/// Deletar um comentário de um projeto
app.delete('/projects/:projectId/comments/:commentId', authenticateToken, async (req, res) => {
  const { projectId, commentId } = req.params;
  
  // Validação para garantir que os parâmetros não sejam undefined
  if (!projectId || !commentId) {
    return res.status(400).send({ message: 'Project ID and Comment ID are required' });
  }

  try {
    console.log('Attempting to delete comment:', { projectId, commentId });

    const [result] = await db.execute(
      `
      DELETE FROM comments
      WHERE id = ? AND project_id = ?
    `,
      [commentId, projectId]
    );

    // Verificar se o comentário foi encontrado e deletado
    if (result.affectedRows === 0) {
      return res.status(404).send({ message: 'Comment not found or already deleted' });
    }

    res.status(200).send({ message: 'Comment deleted successfully' });
  } catch (error) {
    console.error('Error deleting comment:', error);
    res.status(500).send({ message: 'Error deleting comment' });
  }
});