const express = require('express');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456789',
  database: 'university_projects'
});

// Chave secreta para JWT - deve ser complexa e segura
const JWT_SECRET = '12345'; 

// Middleware para verificar o token JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).send({ message: 'Unauthorized' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).send({ message: 'Forbidden' });
    }
    req.user = user;
    next();
  });
};

// Criação das tabelas se não existirem
const initializeDatabase = async () => {
  try {
    await db.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nome VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        matricula VARCHAR(255) NOT NULL,
        curso VARCHAR(255) NOT NULL,
        senha VARCHAR(255) NOT NULL
      );
    `);
    await db.execute(`
      CREATE TABLE IF NOT EXISTS projects (
        id INT PRIMARY KEY AUTO_INCREMENT,
        nome_do_projeto VARCHAR(255) NOT NULL,
        curso VARCHAR(255) NOT NULL,
        descricao TEXT NOT NULL
      );
    `);
    await db.execute(`
      CREATE TABLE IF NOT EXISTS comments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        project_id INT NOT NULL,
        text TEXT NOT NULL,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      );
    `);
    await db.execute(`
      CREATE TABLE IF NOT EXISTS favorites (
        user_id INT NOT NULL,
        project_id INT NOT NULL,
        PRIMARY KEY (user_id, project_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      );
    `);
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1); // Exit process if database initialization fails
  }
};

// Inicialização do banco de dados e início do servidor
initializeDatabase().then(() => {
  app.listen(3000, () => {
    console.log('Server listening on port 3000');
  });
});

// Rotas da API

// Registrar um novo usuário
app.post('/register', async (req, res) => {
  const { nome, email, matricula, curso, senha } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(senha, 10); // Hash da senha
    await db.execute(`
      INSERT INTO users (nome, email, matricula, curso, senha)
      VALUES (?, ?, ?, ?, ?)
    `, [nome, email, matricula, curso, hashedPassword]);
    res.status(201).send({ message: 'User created successfully' });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).send({ message: 'Error creating user' });
  }
});

// Login de usuário
app.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) {
    return res.status(400).send({ message: 'Email and password are required' });
  }

  try {
    const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length > 0) {
      const user = rows[0];
      const match = await bcrypt.compare(senha, user.senha);

      if (match) {
        const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '1h' });
        res.status(200).send({ message: 'Login successful', token, userId: user.id });
      } else {
        res.status(401).send({ message: 'Invalid email or password' });
      }
    } else {
      res.status(401).send({ message: 'Invalid email or password' });
    }
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).send({ message: 'Error logging in' });
  }
});

// Adicionar um comentário a um projeto
app.post('/projects/:projectId/comments', authenticateToken, async (req, res) => {
  const { projectId } = req.params;
  const { text } = req.body;

  if (!text) {
    return res.status(400).send({ message: 'Comment text is required' });
  }

  try {
    await db.execute(`
      INSERT INTO comments (project_id, text)
      VALUES (?, ?)
    `, [projectId, text ]);

    res.status(201).send({ message: 'Comment added successfully' });
  } catch (error) {
    console.error('Error adding comment:', error);
    res.status(500).send({ message: 'Error adding comment' });
  }
});

// Obter os comentários de um projeto
app.get('/projects/:projectId/comments', authenticateToken, async (req, res) => {
  const { projectId } = req.params;

  try {
    const [rows] = await db.execute(`
      SELECT * FROM comments
      WHERE project_id = ?
    `, [projectId]);

    if (rows.length === 0) {
      return res.status(404).send({ message: 'No comments found for this project' });
    }

    res.status(200).send(rows);
  } catch (error) {
    console.error('Error fetching comments:', error);
    res.status(500).send({ message: 'Error fetching comments' });
  }
});


// Editar um comentário
app.put('/projects/:projectId/comments/:commentId', authenticateToken, async (req, res) => {
  const { projectId, commentId } = req.params;
  const { text } = req.body;

  if (!text) {
    return res.status(400).send({ message: 'Comment text is required' });
  }

  try {
    const [result] = await db.execute(`
      UPDATE comments
      SET text = ?
      WHERE id = ? AND project_id = ?
    `, [text, commentId, projectId]);

    if (result.affectedRows === 0) {
      return res.status(404).send({ message: 'Comment not found' });
    }

    res.status(200).send({ message: 'Comment edited successfully' });
  } catch (error) {
    console.error('Error editing comment:', error);
    res.status(500).send({ message: 'Error editing comment' });
  }
});

// Deletar um comentário de um projeto
app.delete('/projects/:projectId/comments/:commentId', authenticateToken, async (req, res) => {
  const { projectId, commentId } = req.params;

  try {
    const [result] = await db.execute(`
      DELETE FROM comments
      WHERE id = ? AND project_id = ?
    `, [commentId, projectId]);

    if (result.affectedRows === 0) {
      return res.status(404).send({ message: 'Comment not found' });
    }

    res.status(200).send({ message: 'Comment deleted successfully' });
  } catch (error) {
    console.error('Error deleting comment:', error);
    res.status(500).send({ message: 'Error deleting comment' });
  }
});

// Alternar status de favorito para um projeto
app.post('/projects/:projectId/favorite', authenticateToken, async (req, res) => {
  const { projectId } = req.params;
  const { userId } = req.user;

  try {
    // Verificar se o favorito já existe
    const [existingFavorite] = await db.execute(`
      SELECT * FROM favorites
      WHERE user_id = ? AND project_id = ?
    `, [userId, projectId]);

    if (existingFavorite.length > 0) {
      // Se existir, deletar o favorito
      await db.execute(`
        DELETE FROM favorites
        WHERE user_id = ? AND project_id = ?
      `, [userId, projectId]);
      res.status(200).send({ message: 'Project unfavorited successfully' });
    } else {
      // Se não existir, adicionar o favorito
      await db.execute(`
        INSERT INTO favorites (user_id, project_id)
        VALUES (?, ?)
      `, [userId, projectId]);
      res.status(200).send({ message: 'Project favorited successfully' });
    }
  } catch (error) {
    console.error('Error updating favorite status:', error);
    res.status(500).send({ message: 'Error updating favorite status' });
  }
});

// Obter status de favorito para um projeto
app.get('/projects/:projectId/favorite-status', authenticateToken, async (req, res) => {
  const { projectId } = req.params;
  const { userId } = req.user;

  try {
    // Verificar se o projeto está favoritado pelo usuário
    const [existingFavorite] = await db.execute(`
      SELECT * FROM favorites
      WHERE user_id = ? AND project_id = ?
    `, [userId, projectId]);

    res.status(200).json({ isFavorited: existingFavorite.length > 0 });
  } catch (error) {
    console.error('Error fetching favorite status:', error);
    res.status(500).json({ message: 'Error fetching favorite status' });
  }
});

// Buscar projetos com comentários
app.get('/search-projects', async (req, res) => {
  const query = req.query.query || '';

  try {
    const [projects] = await db.execute(
      'SELECT * FROM projects WHERE nome_do_projeto LIKE ? OR descricao LIKE ?',
      [`%${query}%`, `%${query}%`]
    );

    for (let project of projects) {
      const [comments] = await db.execute(
        'SELECT * FROM comments WHERE project_id = ?',
        [project.id]
      );
      project.comments = comments;

      // Verificar se o projeto está favoritado
      const [favorites] = await db.execute(`
        SELECT * FROM favorites
        WHERE project_id = ?
      `, [project.id]);
      project.isFavorited = favorites.length > 0;
    }

    res.status(200).json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// Criar um novo projeto
app.post('/api/create-project', authenticateToken, async (req, res) => {
  const { nome_do_projeto, curso, descricao } = req.body;
  try {
    await db.execute(`
      INSERT INTO projects (nome_do_projeto, curso, descricao)
      VALUES (?, ?, ?)
    `, [nome_do_projeto, curso, descricao]);
    res.status(201).send({ message: 'Project created successfully' });
  } catch (error) {
    console.error('Error creating project:', error);
    res.status(500).send({ message: 'Error creating project' });
  }
});

// Obter perfil do usuário
app.get('/api/profile', authenticateToken, async (req, res) => {
  const { userId } = req.user;

  try {
    const [rows] = await db.execute('SELECT * FROM users WHERE id = ?', [userId]);

    if (rows.length > 0) {
      res.status(200).send(rows[0]);
    } else {
      res.status(404).send({ message: 'User not found' });
    }
  } catch (error) {
    console.error('Error fetching user data:', error);
    res.status(500).send({ message: 'Error fetching user data' });
  }
});

// Editar perfil do usuário
app.put('/api/editProfile', authenticateToken, async (req, res) => {
  const { nome, email, matricula, curso, senha } = req.body;

  if (!nome || !email || !matricula || !curso) {
    return res.status(400).send({ message: 'Todos os campos são necessários, exceto senha' });
  }

  try {
    const hashedPassword = senha ? await bcrypt.hash(senha, 10) : null;

    // Criação da string de atualização condicionalmente
    const updateFields = [
      `nome = ?`,
      `email = ?`,
      `matricula = ?`,
      `curso = ?`,
      senha ? `senha = ?` : null
    ].filter(Boolean).join(', ');

    // Adiciona os parâmetros ao array
    const params = [nome, email, matricula, curso];
    if (senha) params.push(hashedPassword);

    // Executa a consulta de atualização
    const result = await db.execute(`
      UPDATE users
      SET ${updateFields}
      WHERE email = ?
    `, [...params, email]);

    if (result[0].affectedRows === 0) {
      return res.status(404).send({ message: 'Usuário não encontrado' });
    }

    res.status(200).send({ message: 'Perfil atualizado com sucesso' });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).send({ message: 'Erro ao atualizar o perfil' });
  }
});
